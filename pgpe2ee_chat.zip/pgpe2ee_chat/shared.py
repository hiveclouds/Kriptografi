from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os

# Buat pasangan kunci RSA (privat dan publik)
def generate_rsa_keypair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    return private_key, public_key

# Serialize (ubah menjadi bytes) kunci publik untuk dibagikan
def serialize_public_key(public_key):
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

# Deserialize (ubah kembali menjadi objek) kunci publik
def deserialize_public_key(public_key_bytes):
    return serialization.load_pem_public_key(public_key_bytes)

# Enkripsi pesan dengan AES dan RSA (E2EE)
def encrypt_message(message, receiver_public_key):
    aes_key = os.urandom(32)  # kunci AES 256-bit
    iv = os.urandom(16)       # initialization vector

    # Enkripsi pesan dengan AES
    cipher = Cipher(algorithms.AES(aes_key), modes.CFB(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(message.encode()) + encryptor.finalize()

    # Enkripsi kunci AES dengan kunci publik penerima
    encrypted_aes_key = receiver_public_key.encrypt(
        aes_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )

    return encrypted_aes_key, iv, ciphertext

# Dekripsi pesan
def decrypt_message(encrypted_aes_key, iv, ciphertext, private_key):
    # Dekripsi kunci AES
    aes_key = private_key.decrypt(
        encrypted_aes_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )

    # Dekripsi pesan
    cipher = Cipher(algorithms.AES(aes_key), modes.CFB(iv))
    decryptor = cipher.decryptor()
    message = decryptor.update(ciphertext) + decryptor.finalize()
    return message.decode()
