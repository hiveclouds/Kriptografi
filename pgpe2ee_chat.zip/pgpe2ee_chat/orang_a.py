from shared import *
import pickle
import os
from cryptography.hazmat.primitives import serialization

# Fungsi untuk memuat atau membuat kunci
def load_or_generate_keypair(private_path, public_path):
    if os.path.exists(private_path):
        with open(private_path, "rb") as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)
        public_key = private_key.public_key()
    else:
        private_key, public_key = generate_rsa_keypair()
        with open(private_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        with open(public_path, "wb") as f:
            f.write(serialize_public_key(public_key))
    return private_key, public_key

# Muat atau buat kunci A
private_a, public_a = load_or_generate_keypair("private_a.pem", "public_a.pem")

# Coba baca kunci publik B jika ada
if os.path.exists("public_b.pem"):
    with open('public_b.pem', 'rb') as f:
        public_b = deserialize_public_key(f.read())
else:
    print("Menunggu kunci publik dari B (public_b.pem)...")
    public_b = None

def menu():
    print("== ORANG A ==")
    print("1. Kirim pesan ke B")
    print("2. Terima pesan dari B")
    choice = input("Pilih: ")

    if choice == "1":
        if not public_b:
            print("Tidak bisa kirim. Kunci publik B belum tersedia.")
            return
        msg = input("Tulis pesan: ")
        encrypted_key, iv, ciphertext = encrypt_message(msg, public_b)
        with open("pesan_ke_b.dat", "wb") as f:
            pickle.dump((encrypted_key, iv, ciphertext), f)
        print("Pesan dikirim!")

    elif choice == "2":
        if not os.path.exists("pesan_ke_a.dat"):
            print("Belum ada pesan.")
            return
        with open("pesan_ke_a.dat", "rb") as f:
            encrypted_key, iv, ciphertext = pickle.load(f)
        try:
            message = decrypt_message(encrypted_key, iv, ciphertext, private_a)
            print("Pesan dari B:", message)
        except Exception as e:
            print("Gagal mendekripsi pesan:", str(e))

menu()
