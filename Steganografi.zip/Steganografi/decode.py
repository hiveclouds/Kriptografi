from PIL import Image

def decode_message(image_path):
    img = Image.open(image_path)
    width, height = img.size
    binary_message = ''
    message = ''

    for y in range(height):
        for x in range(width):
            r, g, b = img.getpixel((x, y))
            binary_message += str(r & 1)
            if len(binary_message) % 8 == 0:
                byte = binary_message[-8:]
                char = chr(int(byte, 2))
                if char == chr(0):
                    return message
                message += char

# Contoh penggunaan:
hasil = decode_message('output.png')
print("Pesan tersembunyi:", hasil)