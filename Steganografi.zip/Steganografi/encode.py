from PIL import Image

def encode_message(image_path, message, output_path):
    img = Image.open(image_path)
    encoded = img.copy()
    width, height = img.size
    message += chr(0)  # null character sebagai penanda akhir

    binary_message = ''.join([format(ord(char), '08b') for char in message])
    data_index = 0

    for y in range(height):
        for x in range(width):
            if data_index < len(binary_message):
                r, g, b = img.getpixel((x, y))
                r = (r & ~1) | int(binary_message[data_index])
                encoded.putpixel((x, y), (r, g, b))
                data_index += 1
            else:
                encoded.save(output_path)
                return
    encoded.save(output_path)

# Contoh penggunaan:
encode_message('image.png', 'Ini rahasia', 'output.png')

