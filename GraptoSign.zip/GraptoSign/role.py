# ======================= user.py =======================
import os
import json
from caesar import caesar_encrypt

class User:
    def __init__(self, username, password_encrypted, purchased=None, is_admin=False):
        self.username = username
        self.password_encrypted = password_encrypted
        self.purchased = set(purchased) if purchased else set()
        self.is_admin = is_admin

    def verify_password(self, password):
        return self.password_encrypted == caesar_encrypt(password)

    def purchase(self, filename):
        self.purchased.add(filename)

    def has_purchased(self, filename):
        return filename in self.purchased

    def to_dict(self):
        return {
            "username": self.username,
            "password_encrypted": self.password_encrypted,
            "purchased": list(self.purchased),
            "is_admin": self.is_admin
        }

class UserManager:
    def __init__(self, db_path="users.db"):
        self.db_path = db_path
        self.users = {}
        self._load_users()

        if "admin" not in self.users:
            admin_password = caesar_encrypt("admin123")
            self.users["admin"] = User("admin", admin_password, is_admin=True)
            self._save_users()

    def _load_users(self):
        if os.path.exists(self.db_path):
            with open(self.db_path, "r") as f:
                data = json.load(f)
                for username, user_data in data.items():
                    self.users[username] = User(
                        username,
                        user_data.get("password_encrypted") or user_data.get("password"),
                        user_data.get("purchased", []),
                        user_data.get("is_admin", False)
                    )

    def _save_users(self):
        with open(self.db_path, "w") as f:
            json.dump({u: user.to_dict() for u, user in self.users.items()}, f)

    def register(self, username, password):
        if username in self.users:
            raise ValueError("Username sudah terdaftar.")
        encrypted_password = caesar_encrypt(password)
        user = User(username, encrypted_password, is_admin=False)
        self.users[username] = user
        self._save_users()
        return user

    def login(self, username, password):
        user = self.users.get(username)
        if user and user.verify_password(password):
            return user
        return None

    def save_user(self, user):
        self.users[user.username] = user
        self._save_users()
