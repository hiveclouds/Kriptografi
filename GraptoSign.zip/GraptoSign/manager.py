# ======================= photo_manager.py =======================
import os
from PIL import Image, ImageDraw, ImageFont

class PhotoManager:
    def __init__(self, folder="photos"):
        self.folder = folder
        self.original_folder = os.path.join(folder, "original")
        self.watermarked_folder = os.path.join(folder, "watermarked")
        os.makedirs(self.original_folder, exist_ok=True)
        os.makedirs(self.watermarked_folder, exist_ok=True)

    def upload_photo(self, filepath):
        name = os.path.basename(filepath)
        original_path = os.path.join(self.original_folder, name)
        watermarked_path = os.path.join(self.watermarked_folder, name)

        image = Image.open(filepath)
        image.save(original_path)

        draw = ImageDraw.Draw(image)
        text = "GraptoSign"

        # Ukuran font dinamis berdasarkan lebar gambar
        font_size = max(20, image.width // 10)
        try:
            font = ImageFont.truetype("arial.ttf", font_size)
        except IOError:
            font = ImageFont.load_default()

        # Hitung posisi teks agar berada di tengah gambar
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (image.width - text_width) // 2
        y = (image.height - text_height) // 2

        draw.text((x, y), text, font=font, fill=(255, 234, 0))  # Tanpa alpha channel

        image.save(watermarked_path)
        return name


    def list_photos(self):
        return os.listdir(self.original_folder)

    def get_original_path(self, name):
        return os.path.join(self.original_folder, name)

    def get_watermarked_path(self, name):
        return os.path.join(self.watermarked_folder, name)
    
    def preview_photo(self, name, original=False):
        from PIL import Image
        path = self.get_original_path(name) if original else self.get_watermarked_path(name)
        if os.path.exists(path):
            img = Image.open(path)
            img.show()
        else:
            print("Gambar tidak ditemukan.")
