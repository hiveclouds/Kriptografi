from role import UserManager
from manager import PhotoManager

user_manager = UserManager()
photo_manager = PhotoManager()
current_user = None

while True:
    if not current_user:
        print("\n=== MENU UTAMA ===")
        print("1. Daftar")
        print("2. Login")
        print("3. Keluar")
        choice = input("Pilih opsi: ")

        if choice == "1":
            username = input("Masukkan username baru: ")
            if username.lower() == "admin":
                print("Tidak bisa menggunakan nama 'admin'.")
                continue
            password = input("Masukkan password: ")
            try:
                user = user_manager.register(username, password)
                print("Pendaftaran berhasil. Silakan login.")
            except ValueError as e:
                print(e)

        elif choice == "2":
            username = input("Masukkan username: ")
            password = input("Masukkan password: ")
            user = user_manager.login(username, password)
            if user:
                current_user = user
                print(f"Login berhasil sebagai '{username}'")
            else:
                print("Login gagal. Username atau password salah.")

        elif choice == "3":
            print("Keluar dari program.")
            break

    else:
        print(f"\n=== MENU ({'ADMIN' if current_user.is_admin else 'USER'} - {current_user.username}) ===")
        if current_user.is_admin:
            print("1. Upload foto")
            print("2. Lihat daftar foto")
            print("3. Logout")
            opsi = input("Pilih opsi: ")

            if opsi == "1":
                path = input("Masukkan path foto: ")
                try:
                    name = photo_manager.upload_photo(path)
                    print(f"Foto '{name}' berhasil diupload.")
                except Exception as e:
                    print(f"Gagal upload: {e}")

            elif opsi == "2":
                photos = photo_manager.list_photos()
                if photos:
                    print("\nDaftar foto tersedia:")
                    for photo in photos:
                        print(f"- {photo}")
                else:
                    print("Belum ada foto yang diupload.")

            elif opsi == "3":
                print("Logout berhasil.")
                current_user = None

        else:
            print("1. Lihat daftar foto")
            print("2. Beli foto")
            print("3. Lihat foto")
            print("4. Logout")
            opsi = input("Pilih opsi: ")

            if opsi == "1":
                photos = photo_manager.list_photos()
                if photos:
                    print("\nDaftar foto tersedia:")
                    for photo in photos:
                        print(f"- {photo}")
                else:
                    print("Belum ada foto yang tersedia.")

            elif opsi == "2":
                name = input("Masukkan nama file yang ingin dibeli: ")
                # Tambahan validasi keberadaan foto
                if name in photo_manager.list_photos():
                    current_user.purchase(name)
                    user_manager.save_user(current_user)
                    print(f"Anda telah membeli '{name}'")
                else:
                    print("Error: Foto tidak ditemukan dalam sistem.")

            elif opsi == "3":
                name = input("Masukkan nama file: ")
                if name not in photo_manager.list_photos():
                    print("Error: Foto tidak ditemukan dalam sistem.")
                elif current_user.has_purchased(name):
                    print("Menampilkan foto tanpa watermark...")
                    photo_manager.preview_photo(name, original=True)
                else:
                    print("Menampilkan foto dengan watermark (belum dibeli)...")
                    photo_manager.preview_photo(name, original=False)

            elif opsi == "4":
                print("Logout berhasil.")
                current_user = None
